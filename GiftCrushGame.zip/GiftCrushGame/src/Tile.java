
public class Tile {
	int value;
	int imageValue;
	int positionColumn;
	int positionRow;
	boolean isStar;
	Color c;
	public enum Color{	GREEN, BLUE, PURPLE, PINK, ORANGE, RED	}

	
	public Tile(int row, int col, boolean star, int val, String colorName){
		positionRow = row;
		positionColumn = col;
		isStar = star;
		value = val;
		/* CURRENTLY CANT FIGURE OUT HOW TO PASS ENUM COLOR */
		c = Color.valueOf(colorName);
	}
	String getColor(){
		return c.name();
	}
	int getValue()
	{
		return value;
	}
	int getColumn()
	{
		return positionColumn;
	}
	int getRow()
	{
		return positionRow;
	}
	boolean getIsStar(){
		return isStar;
	}
	public String toString(){
		String s = "[";
		s = s.concat(positionRow +" ");
		s = s.concat(positionColumn + " ");
		s = s.concat(value + " ");
		s = s.concat(isStar + " ");
		s = s.concat(c + "");
		s += "] ";
		return s;
	}
	void updateColumn(int c){
		positionColumn = c;
	}
	void updateRow(int r){
		positionRow = r;
	}
}
