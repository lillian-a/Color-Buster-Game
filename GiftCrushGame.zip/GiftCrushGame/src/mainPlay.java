import java.util.*;

public class mainPlay {
	public enum Color{	GREEN, BLUE, PURPLE, PINK, ORANGE, RED	}
	static Random r;
	public static void main(String[] args) {
		ScoreBoard score = new ScoreBoard();
		String s;
		Board b = new Board(6,6,score,3,20,4);
		b.initializePlayableBoard();
		s = b.toString();
		System.out.println(s);
		int num;
		num = b.tileTouched(5,5);
		s = b.toString();
		System.out.println(s);
		System.out.println("Num: "+num);
		
	}
	static boolean beStar(){
		int num = (int) (Math.random() * 100) + 1;
		   if (num <= 20)
		      return true;
		   return false;
	}

}
