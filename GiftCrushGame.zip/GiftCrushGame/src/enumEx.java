
public class enumEx {

}
