import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class giftCrushTest {
	Board board;
	ScoreBoard score;
	public enum Color{	GREEN, BLUE, PURPLE, PINK, ORANGE, RED	};
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		score = new ScoreBoard();
	}

	@After
	public void tearDown() throws Exception {
		board = null;
		score = null;
	}
	/* TILE CLASS TESTERS */
	@Test
	public void testTileGetSetCol(){
		int expected = 2;
		Color c = Color.BLUE;
		Tile t = new Tile(3,3,true,5,c.name());
		t.updateColumn(expected);
		int actual = t.getColumn();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetSetRow(){
		int expected = 2;
		Color c = Color.BLUE;
		Tile t = new Tile(3,3,true,5,c.name());
		t.updateRow(expected);
		int actual = t.getRow();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetBlueColor(){
		String expected = "BLUE";
		Color c = Color.BLUE;
		Tile t = new Tile(3,3,true,5,c.name());
		String actual = t.getColor();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetGreenColor(){
		String expected = "GREEN";
		Color c = Color.GREEN;
		Tile t = new Tile(3,3,true,5,c.name());
		String actual = t.getColor();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetPurpleColor(){
		String expected = "PURPLE";
		Color c = Color.PURPLE;
		Tile t = new Tile(3,3,true,5,c.name());
		String actual = t.getColor();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetPinkColor(){
		String expected = "PINK";
		Color c = Color.PINK;
		Tile t = new Tile(3,3,true,5,c.name());
		String actual = t.getColor();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetOrangeColor(){
		String expected = "ORANGE";
		Color c = Color.ORANGE;
		Tile t = new Tile(3,3,true,5,c.name());
		String actual = t.getColor();
		assertEquals(expected, actual);
	}
	@Test
	public void testTileGetREDColor(){
		String expected = "RED";
		Color c = Color.RED;
		Tile t = new Tile(3,3,true,5,c.name());
		String actual = t.getColor();
		assertEquals(expected, actual);
	}
	/* BOARD CLASS TESTERS */
	@Test
	public void testBoardCreateNull() {
		board = new Board(6,6,score,3,20,4);
		board.createBoard();
		Tile[][] expected = new Tile[6][6];
		Tile[][] actual = board.getBoard();
		assertArrayEquals(expected, actual);
		
	}
	@Test
	// FOR TESTING ONLY - TO KNOW THAT CAN GIVE PARAMETERS TO TEST CONDITIONS
	public void testBoardSetter(){
		board = new Board(4,4,score,3,20,4);
		Tile[][] expected = new Tile[4][4];
		for(int row = 3; row >= 0; row--){
			for(int col = 0; col < 4; col++){
				Color c = Color.BLUE;
				boolean star = board.beStar();
				int pts = star ? 10 : 5;
				expected[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
		board.setBoard(expected);
		Tile[][] actual = board.getBoard();
		assertArrayEquals(expected, actual);
	}
	@Test
	public void testBoardIsMoveAvailable(){
		board = new Board(4,4,score,3,20,4);
		Tile[][] expected = new Tile[4][4];
		for(int row = 3; row >= 0; row--){
			for(int col = 0; col < 4; col++){
				Color c = Color.BLUE;
				boolean star = board.beStar();
				int pts = star ? 10 : 5;
				expected[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
		board.setBoard(expected);
		boolean actual = board.isMoveAvailable();
		assertTrue(actual);
	}
	@Test
	public void testBoardTileTouchedBOTLEFT(){
		board = new Board(4,4,score,3,20,4);
		Tile[][] trial = new Tile[4][4];
		for(int row = 3; row >= 0; row--){
			for(int col = 0; col < 4; col++){
				Color c = Color.BLUE;
				boolean star = board.beStar();
				int pts = star ? 10 : 5;
				trial[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
		board.setBoard(trial);
		int expected = 4*4;
		int actual = board.tileTouched(0,0);
		assertEquals(actual, expected);
	}
	@Test
	public void testBoardTileTouchedBOTRIGHT(){
		board = new Board(4,4,score,3,20,4);
		Tile[][] trial = new Tile[4][4];
		for(int row = 3; row >= 0; row--){
			for(int col = 0; col < 4; col++){
				Color c = Color.BLUE;
				boolean star = board.beStar();
				int pts = star ? 10 : 5;
				trial[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
		board.setBoard(trial);
		int expected = 4*4;
		int actual = board.tileTouched(0,3);
		assertEquals(actual, expected);
	}
	@Test
	public void testBoardTileTouchedTOPLEFT(){
		board = new Board(4,4,score,3,20,4);
		Tile[][] trial = new Tile[4][4];
		for(int row = 3; row >= 0; row--){
			for(int col = 0; col < 4; col++){
				Color c = Color.BLUE;
				boolean star = board.beStar();
				int pts = star ? 10 : 5;
				trial[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
		board.setBoard(trial);
		int expected = 4*4;
		int actual = board.tileTouched(3,0);
		assertEquals(actual, expected);
	}
	@Test
	public void testBoardTileTouchedTOPRIGHT(){
		board = new Board(4,4,score,3,20,4);
		Tile[][] trial = new Tile[4][4];
		for(int row = 3; row >= 0; row--){
			for(int col = 0; col < 4; col++){
				Color c = Color.BLUE;
				boolean star = board.beStar();
				int pts = star ? 10 : 5;
				trial[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
		board.setBoard(trial);
		int expected = 4*4;
		int actual = board.tileTouched(3,3);
		assertEquals(actual, expected);
	}
	

}
