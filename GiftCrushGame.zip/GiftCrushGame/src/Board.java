import java.util.*;

public class Board {
	/* CHANGE BY LEVEL */
	int threshold;
	int numRow;
	int numColumn;
	int starPercent;
	int colorAllowed;
	ArrayList<Tile> b;
	Tile[][] board;
	HashSet<Tile> matches;
	ScoreBoard score;
	public enum Color{	GREEN, BLUE, PURPLE, PINK, ORANGE, RED	}
	Random r;
	public Board(int numR,  int numC, ScoreBoard scores, int thresh, int star, int cAllow){
		score = scores;
		numRow = numR;
		numColumn = numC;
		starPercent = star;
		colorAllowed = cAllow;
		r = new Random();
		matches = new HashSet<Tile>();
		threshold = thresh;
	}
	Tile[][] getBoard(){
		return board;
	}
	// FOR TESTING PURPOSES ONLY
	HashSet<Tile> getMatches(){
		return matches;
	}
	// FOR TESTING PURPOSES ONLY
	void setBoard(Tile[][] test){
		board = test;
	}
	void initializeBoard()
	{
		for(int row = numRow-1; row >= 0; row--){
			for(int col = 0; col < numColumn; col++){
				Color c = Color.values()[Math.abs(r.nextInt())%colorAllowed];
				boolean star = beStar();
				int pts = star ? 10 : 5;
				board[row][col] = new Tile(row, col, star, pts, c.name());
			}
		}
	}
	void createBoard(){
		board = new Tile[numRow][numColumn];
	}
	void initializePlayableBoard()
	{
		createBoard();
		do {
			initializeBoard();
		} while (!isMoveAvailable());
		
	}
	
	boolean beStar(){
		int num = (int) (Math.random() * 100) + 1;
		   if (num <= starPercent)
		      return true;
		   return false;
	}
	
	void explodeTiles(HashSet<Tile> h)
	{
		Iterator<Tile> it = h.iterator();
		int countRegular = 0;
		int countStar = 0;
		while(it.hasNext()){
			Tile t = it.next();
			if(t.getIsStar()){
				countStar++;
			}
			else{
				countRegular++;
			}
			board[t.getRow()][t.getColumn()] = null;
		}
		score.updateScore(countRegular, countStar);
	}
	
	void collapseColumns()
	{ 
		for(int i = 0; i < numColumn; i++){
			collapseColumn(i);
		}
	}
	
	void collapseColumn(int n)
	{
		int j = 0;
		// create copy of column with tiles set to null
		Tile[] copyCol = new Tile[numRow];
		for(int i = 0; i < numRow; i++){
			copyCol[i] = null;
		}
		// transfer non-null tiles from copy to copyCol
		for(int l = 0; l < numRow; l++){
			if(board[l][n] != null){
				copyCol[j] = board[l][n];
				j++;
			}
		}
		if(j != numRow-1){
			for(int k = j; k < numRow; k++){
				copyCol[k] = null;
			}
		}
		// replace n column with copycolumn
		for(int i = 0, k = 0; i < numRow; i++, k++){
			board[i][n] = copyCol[k];
			if(board[i][n] != null){
				board[i][n].updateColumn(n);
				board[i][n].updateRow(i);
			}
		}
	}
	
	void fillColumns()
	{
		for(int i = 0; i < numColumn; i++){
			fillColumn(i);
		}
	}
	
	void fillColumn(int n)
	{
		for(int i = 0; i < numRow; i++){
			if(board[i][n] == null){
				Color c = Color.values()[Math.abs(r.nextInt())%colorAllowed];
				boolean star = beStar();
				int pts = star ? 10 : 5;
				board[i][n] = new Tile(i,n, star, pts, c.name());
			}
		}
	}
	
	int tileTouched(int row, int column)
	{
		Tile tile = board[row][column];
		matches.clear();
		matchingTiles(row, column, Color.valueOf(tile.getColor()));
		if(matches.size() >= threshold){
			explodeTiles(matches);
			collapseColumns();
			fillColumns();
		}
		return matches.size();
	}
	void matchingTiles(int row, int column, Color color)
	{
		findNeighbors(row, column, color, matches);
	}
	
	boolean isMoveAvailable()
	{
		// Tile t = null;
		for(int row = numRow-1; row >= 0; row--){
			for(int col = 0; col < numColumn; col++){
				Tile tile = board[row][col];
				if(isTileMoveAvailable(tile.getRow(), tile.getColumn(), Color.valueOf(tile.getColor()))){
					// t = tile;
					return true;
				}
			}
		}
		// return t
		return false;
	}
	/* (private)
	 * function that calls check if is tile or null
	 * null = no matches
	 * tile = at least 1 match
	 * Tile isMoveAvailable(){
	 * 		for(int row = 0; row < numRow; row++){
	 * 			for(int col = 0; col < numColumn; col++){
	 * 				Tile tile = board[row][col];
	 *				if(isTileMoveAvailable(tile.getRow(), tile.getColumn(), Color.valueOf(tile.getColor()))){
	 *					return tile;
	 *				}
	 *			}
	 *		}
	 *		return null;
	 * }		
	 */
	
	boolean isTileMoveAvailable(int row, int column, Color color)
	{
		matches.clear();
		findNeighbors(row, column, color, matches);
		if(matches.size() >= threshold){
			return true;
		}
		return false;
	}	


	void findNeighbors(int row, int column, Color c, HashSet<Tile> matches)
	{
		Tile match = board[row][column];
		if(matches.contains(match))
			return;
		else
			matches.add(match);
			
		// if look up / north
		if(isNorthMatch(row, column, c)){
			findNeighbors(row+1, column, c, matches);
		}
		// if look down / south
		if(isSouthMatch(row, column, c)){
			findNeighbors(row-1, column, c, matches);
		}
		
		// if look left / west
		if(isWestMatch(row, column, c)){
			findNeighbors(row, column-1, c, matches);
		}
		
		// if look right / east
		if(isEastMatch(row, column, c)){
			findNeighbors(row, column+1, c, matches);
		}
	}
	public boolean isNorthMatch(int row, int col, Color c){
		Color b;
		if(row >= 0 && row < numRow-1){
			if(c.equals(b = Color.valueOf(board[row+1][col].getColor()))){
				return true;
			} else{
				return false;
			}
		} else {
			return false;
		}
	}
	public boolean isSouthMatch(int row, int col, Color c){
		Color b;
		if(row > 0 && row <= numRow-1){
			if(c.equals(b = Color.valueOf(board[row-1][col].getColor()))){
				return true;
			} else{
				return false;
			}
		} else {
			return false;
		}
	}
	public boolean isWestMatch(int row, int col, Color c){
		Color b;
		if(col > 0 && col <= numColumn-1){
			if(c.equals(b = Color.valueOf(board[row][col-1].getColor()))){
				return true;
			} else{
				return false;
			}
		} else {
			return false;
		}
	}
	public boolean isEastMatch(int row, int col, Color c){
		Color b;
		if(col >= 0 && col < numColumn-1){
			if(c.equals(b = Color.valueOf(board[row][col+1].getColor()))){
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public String toString(){
		String s = "";
		for(int row = numRow - 1; row >= 0; row--) {
			for(int col = 0; col < numColumn; col++) {
				if(board[row][col] != null) {
					s += board[row][col].toString();
				} else {
					System.out.println(s);
					s += "[-----]";
				}
			}
			s = s + "\n";
		}
		return s;
	}

}
