import java.util.ArrayList;
import java.util.Collections;

public class ScoreBoard {
	final int MAX_SCORES = 10;
	ArrayList<Integer> HighScoresEasy;
	ArrayList<Integer> HighScoresMedium;
	ArrayList<Integer> HighScoresHard;
	int currentScore;
	int savedScore;
	int level_diff;

	// SCORE BOARD CONSTRUCTOR
	public ScoreBoard(){
		HighScoresEasy = new ArrayList<Integer>();
		HighScoresMedium = new ArrayList<Integer>();
		HighScoresHard = new ArrayList<Integer>();
		initializeScoreBoard();
	}
	// INITIALIZE
	void initializeScoreBoard(){
		for(int i = 0; i < MAX_SCORES-1; i++){
			HighScoresEasy.add(0);
			HighScoresMedium.add(0);
			HighScoresHard.add(0);
		}
	}
	// GET DATA FROM BOARD TO UPDATE SCORE
	int updateScore(int nStdTiles, int nStarTiles)
	{
		int sum = currentScore;
		sum = sum + (nStdTiles * 5);
		sum = sum + (nStarTiles * 10);
		// ADD PART ABOUT MULTI BONUSES
		currentScore = sum;
		return sum;
	}
	void clearScores()
	{
		HighScoresEasy.clear();
		HighScoresMedium.clear();
		HighScoresHard.clear();
	}
	void sortHighScores(String level)
	{
		if(level == "Easy"){
			Collections.sort(HighScoresEasy);
			Collections.reverse(HighScoresEasy);
		}
		if(level == "Medium"){
			Collections.sort(HighScoresMedium);
			Collections.reverse(HighScoresMedium);
		}
		if(level == "Hard"){
			Collections.sort(HighScoresHard);
			Collections.reverse(HighScoresHard);
		}
	}
	
	ArrayList<Integer> getHighScores(String level)
	{
		if(level == "Easy"){
			return HighScoresEasy;
		}
		else if(level == "Medium"){
			return HighScoresMedium;
		}
		// *****
		// else if(level == "Hard"){
		else{
			return HighScoresHard;
		}
	}
	
	void addHighScore(int score, String level)
	{
		if(level == "Easy"){
			if(checkIfHighScore(score, level)){
				HighScoresEasy.add(score);
				sortHighScores(level);
				HighScoresEasy.remove(MAX_SCORES+1);
			}
		}
		if(level == "Medium"){
			if(checkIfHighScore(score, level)){
				HighScoresMedium.add(score);
				sortHighScores(level);
				HighScoresMedium.remove(MAX_SCORES+1);
			}	
		}
		if(level == "Hard"){
			if(checkIfHighScore(score, level)){
				HighScoresHard.add(score);
				sortHighScores(level);
				HighScoresHard.remove(MAX_SCORES+1);
			}
		}
	}
	
	boolean checkIfHighScore(int score, String level){
		boolean flag  = false;
		int i;
		if(level == "Easy"){
			for(i = 0; i < HighScoresEasy.size(); i++){
				if(score > HighScoresEasy.get(i))
					flag = true;
			}
		}
		if(level == "Medium"){
			for(i = 0; i < HighScoresMedium.size(); i++){
				if(score > HighScoresMedium.get(i))
					flag = true;
			}	
		}
		if(level == "Hard"){
			for(i = 0; i < HighScoresHard.size(); i++){
				if(score > HighScoresHard.get(i))
					flag = true;
			}
		}
		return flag;
	}
}
